
import requests

def test_create_user():
    r = requests.post("http://127.0.0.1:5000/users", json={"username": "test", "password": "123"})
    assert r.status_code == 201
