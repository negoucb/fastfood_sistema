
import requests

def main():
    while True:
        print("\n1 - Login\n2 - Criar Usuário\n3 - Ver Produtos\n4 - Sair")
        choice = input("Escolha: ")

        if choice == '1':
            username = input("Usuário: ")
            password = input("Senha: ")
            res = requests.post("http://127.0.0.1:5000/login", json={"username": username, "password": password})
            print(res.json())

        elif choice == '2':
            username = input("Novo usuário: ")
            password = input("Senha: ")
            res = requests.post("http://127.0.0.1:5000/users", json={"username": username, "password": password})
            print(res.json())

        elif choice == '3':
            res = requests.get("http://127.0.0.1:5000/products")
            for p in res.json():
                print(f"{p['id']}: {p['name']} - R${p['price']}")

        elif choice == '4':
            break
